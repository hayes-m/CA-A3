<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);
	if(!$conn){
	die("Error: Failed to connect to database.");
	}

$wineOut=mysqli_query($conn,'select * from wine order by wine_id desc');

$grape=mysqli_query($conn,'select grape_id, grape_name, style from grape order by grape_name asc');
$winemaker=mysqli_query($conn,'select winemaker_id, winemaker_name from winemaker order by winemaker_name asc');

$recent=mysqli_query($conn,'select * from wine order by wine_id desc limit 1');

?>

<html>
        <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="style.css">

		<div class = "banner">
<div class = "logo"><a href=index.php>
                        <img class = "img" src = "glassr.png" alt="glass" width="75" height="75">
                        <h1>wine_
                        <br>
                        inline
                        </h1></a>
                        </div>
			<div class = "menu"
			<ul>
    				<li><a href=wine.php>wines</a><br><a href=winemaker.php>winemakers</a></li>
    				<li><a href=grape.php>grapes</a><br><a href=region.php>regions</a></li>
    				<li><a href=customer.php>customers</a><br><a href=address.php>addresses</a></li>
    				<li><a href=order.php>orders</a><br><a href=warehouse.php>warehouses</a></li>
			</ul>
			</div>
        	</div>
	</head>

        <body>
	<br>
	<div class = "split">
		<div class = "enter">

			<form action="wineUp.php" method="post">
                        <h3>enter new wine</h3>

                        <b>wine name<br><input type="text" name="Wine_Name" value=""/></b>
                        <br><br>

			<b>abv<br><input type="number" name="ABV" value="" min="1" max="40"/></b>
                        <br><br>

			<b>grape</b><br>
				<select name="Grape_Name">
				<option>select</option>
				<?php
				while($gdata=mysqli_fetch_array($grape)){
				echo "<option value='".$gdata['grape_id']."'>" .$gdata['grape_name'] ."</option>";
				}
				?>
				</select>
				<br>
				<small><i><a href="grape.php">...add new</a></i></small>
                        	<br><br>

			<b>price<br><input type="number" name="Price" value="" /></b>
                        <br><br>

			<b>stock<br><input type="number" name="Stock" value="" /></b>
                        <br><br>

			<b>winemaker</b><br>
                                <select name="Winemaker_Name">
                                <option>select</option>
                                <?php
                                while($wdata=mysqli_fetch_array($winemaker)){
                                echo "<option value='".$wdata['winemaker_id']."'>" .$wdata['winemaker_name'] ."</option>";
                                }
                        	?>
                        	</select>
                                <br>
				<small><i><a href="winemaker.php">...add new</a></i></small>
				<br><br>

			<input type="submit" value="enter" />
                </form>
		<br>
		<hr>
		<div class="latest">

<?php
		echo "<br><b><i>latest entry: </i></b>";
                while($showrecent=mysqli_fetch_array($recent,MYSQLI_ASSOC)){
                echo "<br><b>wine id: </b>".$showrecent['wine_id'];
                echo "<br><b>wine name: </b>".$showrecent['wine_name'];
                echo "<br><b>abv(%): </b>".$showrecent['abv'];
                echo "<br><b>grape id: </b>".$showrecent['grape_id'];
                echo "<br><b>price: </b>".$showrecent['price'];
                echo "<br><b>stock: </b>".$showrecent['stock'];
                echo "<br><b>winemaker id: </b>".$showrecent['winemaker_id'];
                }
?>
		</div>
		</div>
		<div class="result">

                <div align="center">
<?php
		echo "<br>";
 		echo "<table border='0' cellspacing='0' width='100%'>
                <tr>
                <th>wine id</th>
                <th>wine name</th>
                <th>abv(%)</th>
                <th>grape id</th>
                <th>price</th>
                <th>stock</th>
                <th>winemaker id</th>
                </tr>";


		while($mywine=mysqli_fetch_array($wineOut,MYSQLI_ASSOC)){
		echo "<tr>";
		echo "<td>".$mywine['wine_id']."</td>";
		echo "<td>".$mywine['wine_name']."</td>";
		echo "<td>".$mywine['abv']."</td>";
		echo "<td>".$mywine['grape_id']."</td>";
		echo "<td>".$mywine['price']."</td>";
		echo "<td>".$mywine['stock']."</td>";
		echo "<td>".$mywine['winemaker_id']."</td>";
		echo "</tr>";
		echo "</div>";
		}
		echo "</table>";

?>
	</body>
</html>

