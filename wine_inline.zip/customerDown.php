<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$cid=$_POST['cid'];

mysqli_query($conn,"delete from customer where customer_id='".$cid."'");
header('Location: customer.php');

?>
