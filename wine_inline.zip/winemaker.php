<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);
	if(!$conn){
	die("Error: Failed to connect to database.");
	}

$winemakerOut=mysqli_query($conn,'select * from winemaker order by winemaker_id desc');

$region=mysqli_query($conn,'select region_id, region_name from region order by region_name asc');

$recent=mysqli_query($conn,'select * from winemaker order by winemaker_id desc limit 1');

?>

<html>
        <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="style.css">

		<div class = "banner">
<div class = "logo"><a href=index.php>
                        <img class = "img" src = "glassr.png" alt="glass" width="75" height="75">
                        <h1>wine_
                        <br>
                        inline
                        </h1></a>
                        </div>
			<div class = "menu"
			<ul>
    				<li><a href=wine.php>wines</a><br><a href=winemaker.php>winemakers</a></li>
    				<li><a href=grape.php>grapes</a><br><a href=region.php>regions</a></li>
    				<li><a href=customer.php>customers</a><br><a href=address.php>addresses</a></li>
    				<li><a href=order.php>orders</a><br><a href=warehouse.php>warehouses</a></li>
			</ul>
			</div>
        	</div>
	</head>

        <body>
	<br>
	<div class = "split">
		<div class = "enter">

			<form action="winemakerUp.php" method="post">
				<h3>enter new winemaker</h3>

				<b>winemaker name<br><input type="text" name="Winemaker_Name" value=""/></b>
				<br><br>

				<b>vineyard name<br><input type="text" name="Vineyard" value=""/></b>
				<br><br>
							
				<b>year established<br><input type="number" name="Year_Established" value="" max="<?php echo date("Y"); ?>"/></b>
				<br><br>

				<b>region</b><br>
					<select name="Region_Name">
					<option>select</option>
					<?php
					while($rdata=mysqli_fetch_array($region)){
					echo "<option value='".$rdata['region_id']."'>" .$rdata['region_name'] ."</option>";
					}
					?>
					</select>
                                        <br>
                                        <small><i><a href="region.php">...add new</a></i></small>
					<br><br>

			<input type="submit" value="enter" />
                </form>
		<div class="latest">
                <br>
                <hr>

<?php
                echo "<br><b><i>latest entry: </i></b>";
                while($showrecent=mysqli_fetch_array($recent,MYSQLI_ASSOC)){
                echo "<br><b>winemaker id: </b>".$showrecent['winemaker_id'];
                echo "<br><b>winemaker name: </b>".$showrecent['winemaker_name'];
                echo "<br><b>vineyard: </b>".$showrecent['vineyard'];
                echo "<br><b>year established: </b>".$showrecent['year_established'];
                echo "<br><b>region id: </b>".$showrecent['region_id'];
                }
?>
                </div>


		</div>

		<div class="result">
		<br>
<?php

		echo "<table border='0' cellspacing='0' width='100%'>
		<tr>
		<th>winemaker id</th>
		<th>winemaker name</th>
		<th>vineyard</th>
		<th>year established</th>
		<th>region id</th>
		</tr>";

		while($mywinemaker=mysqli_fetch_array($winemakerOut,MYSQLI_ASSOC)){
?>
		<div align="center"

<?php
		echo "<tr>";
		echo "<td>".$mywinemaker['winemaker_id']."</td>";
		echo "<td>".$mywinemaker['winemaker_name']."</td>";
		echo "<td>".$mywinemaker['vineyard']."</td>";
		echo "<td>".$mywinemaker['year_established']."</td>";
		echo "<td>".$mywinemaker['region_id']."</td>";
		echo "</tr>";
		echo "</div>";
		}
		echo "</table>";

?>
	</body>
</html>



