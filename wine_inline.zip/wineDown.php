<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

//if(mysqli_connect_error()){
//echo "Connection failure: ".mysqli_connect_error();

$id=$_POST['id'];

mysqli_query($conn,"delete from wine where wine_id='".$id."'");
//}
header('Location: wine.php');

?>
