<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$region_name=$_POST['Region_Name'];
$country=$_POST['Country'];

mysqli_query($conn,"INSERT into region (region_name,country) VALUES ('$region_name','$country')");
header('Location: region.php');
?>


