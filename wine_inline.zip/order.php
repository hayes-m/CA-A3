<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);
	if(!$conn){
	die("Error: Failed to connect to database.");
	}

$orderOut=mysqli_query($conn,'select * from wine_inline.order order by order_id desc');

$wine=mysqli_query($conn,'select wine_id, wine_name from wine order by wine_name asc');
$customer=mysqli_query($conn,'select customer_id, customer_surname, customer_forename from customer order by customer_surname asc');
$warehouse=mysqli_query($conn,'select warehouse_ecode, warehouse_county from warehouse order by warehouse_county asc');

$order_total=mysqli_query($conn, 'select (w.price*o.quantity) as order_total from wine_inline.order o join wine w on w.wine_id=o.wine_id order by order_id desc');

$recent=mysqli_query($conn,'select * from wine_inline.order order by order_id desc limit 1');



?>

<html>
        <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="style.css">

		<div class = "banner">
<div class = "logo"><a href=index.php>
                        <img class = "img" src = "glassr.png" alt="glass" width="75" height="75">
                        <h1>wine_
                        <br>
                        inline
                        </h1></a>
                        </div>
			<div class = "menu"
			<ul>
    				<li><a href=wine.php>wines</a><br><a href=winemaker.php>winemakers</a></li>
    				<li><a href=grape.php>grapes</a><br><a href=region.php>regions</a></li>
    				<li><a href=customer.php>customers</a><br><a href=address.php>addresses</a></li>
    				<li><a href=order.php>orders</a><br><a href=warehouse.php>warehouses</a></li>
			</ul>
			</div>
        	</div>
	</head>

        <body>
	<br>
	<div class = "split">
		<div class = "enter">

			<form action="orderUp.php" method="post">
				<h3>enter new order</h3>

				<b>wine name</b><br>
					<select name="Wine_Name">
						<option>select</option>
						<?php
						while($wdata=mysqli_fetch_array($wine)){
						echo "<option value='".$wdata['wine_id']."'>" .$wdata['wine_name'] ."</option>";
						}
						?>
					</select>
                                        <br>
                                        <small><i><a href="wine.php">...add new</a></i></small>
				<br><br>

				<b>customer name</b><br>
					<select name="Customer_Name">
						<option>select</option>
						<?php
						while($cdata=mysqli_fetch_array($customer)){
						echo "<option value='".$cdata['customer_id']."'>" .$cdata['customer_surname'].", ".$cdata['customer_forename'] ."</option>";
						}
						?>
					</select>
                                        <br>
                                        <small><i><a href="customer.php">...add new</a></i></small>

				<br><br>

				<b>warehouse</b><br>
					<select name="Warehouse">
						<option>select</option>
						<?php
						while($whdata=mysqli_fetch_array($warehouse)){
						echo "<option value='".$whdata['warehouse_ecode']."'>" .$whdata['warehouse_county'] ."</option>";
						}
						?>
					</select>
				<br><br>

				<b>quantity<br><input type="number" name="Quantity" value="" min="1"/></b>
				<br><br>

			<input type="submit" value="enter" />
                </form>

		<div class="latest">
                <br>
                <hr>

<?php
                echo "<br><b><i>latest entry: </i></b>";
                while($showrecent=mysqli_fetch_array($recent,MYSQLI_ASSOC)){
                echo "<br><b>order id: </b>".$showrecent['order_id'];
                echo "<br><b>wine id: </b>".$showrecent['wine_id'];
                echo "<br><b>customer id: </b>".$showrecent['customer_id'];
                echo "<br><b>timestamp: </b>".$showrecent['timestamp'];
                echo "<br><b>quantity: </b>".$showrecent['quantity'];
                echo "<br><b>warehouse eircode: </b>".$showrecent['warehouse_ecode'];
                }
?>
                </div>
		 <br><hr><br>
                <b>DELETE RECORD</b>
                <form action="orderDown.php" method="post">
                order_id#<br> <input type="number" name="oid" /><br>
                        <input type="submit" value="delete" />
                </form>

		</div>

		<div class="result">
		<br>
<?php

		echo "<table border='0' cellspacing='0' width='100%'>
		<tr>
		<th>order id</th>
		<th>wine id</th>
		<th>customer id</th>
		<th>timestamp</th>
		<th>quantity</th>
		<th>warehouse eircode</th>
		<th>order total</th>
		</tr>";


		while($myorder=mysqli_fetch_array($orderOut,MYSQLI_ASSOC)){
			$total=mysqli_fetch_array($order_total,MYSQLI_ASSOC)


?>
		<div align="center"

<?php
		echo "<tr>";
		echo "<td>".$myorder['order_id']."</td>";
		echo "<td>".$myorder['wine_id']."</td>";
		echo "<td>".$myorder['customer_id']."</td>";
		echo "<td>".$myorder['timestamp']."</td>";
		echo "<td>".$myorder['quantity']."</td>";
		echo "<td>".$myorder['warehouse_ecode']."</td>";
		echo "<td>".$total['order_total']."</td>";
		echo "</tr>";
		}

		echo "</div>";
		echo "</table>";

?>
	</body>
</html>
