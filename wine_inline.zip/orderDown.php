
<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$oid=$_POST['oid'];

mysqli_query($conn,"delete from wine_inline.order where order_id='".$oid."'");
header('Location: order.php');

?>
