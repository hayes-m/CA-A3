<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$grape_name=$_POST['Grape_Name'];
$style=$_POST['Style'];

mysqli_query($conn,"INSERT into grape (grape_name,style) VALUES ('$grape_name','$style')");
header('Location: grape.php');
?>


