<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$wine_id=$_POST['Wine_Name'];
$customer_id=$_POST['Customer_Name'];
$timestamp=date('Y-m-d H:i:s');
$quantity=$_POST['Quantity'];
$warehouse_ecode=$_POST['Warehouse'];

mysqli_query($conn,"INSERT into wine_inline.order (wine_id,customer_id,timestamp,quantity,warehouse_ecode) VALUES ('$wine_id','$customer_id','$timestamp','$quantity','$warehouse_ecode')");
header('Location: order.php');
?>


