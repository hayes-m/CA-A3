<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);
	if(!$conn){
	die("Error: Failed to connect to database.");
	}

$red='';
$white='';

$red=mysqli_query($conn, "select count(wine_id) as reds from wine w join grape g on w.grape_id=g.grape_id and g.style='red'");
$white=mysqli_query($conn, "select count(wine_id) as whites from wine w join grape g on w.grape_id=g.grape_id and g.style='white'");

$rrow=mysqli_fetch_assoc($red);
$wrow=mysqli_fetch_assoc($white);

$num_red=$rrow['reds'];
$num_white=$wrow['whites'];



$result=mysqli_query($conn, "select g.grape_name, count(*) as grape_count from wine w join grape g on w.grape_id=g.grape_id group by w.grape_id order by g.style,g.grape_name");

$regions=mysqli_query($conn, "select r.country, count(*) as vineyards from winemaker w join region r on w.region_id=r.region_id group by r.country");

$county=mysqli_query($conn, "select county,count(*) as customers from address group by county");

$monthly_orders=mysqli_query($conn, "select date_format(timestamp,'%m/%Y') as month,(w.price*o.quantity) as order_total from wine_inline.order o
join wine w on w.wine_id=o.wine_id group by month order by timestamp");

?>

<html>
  <head>
    <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript">
    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['style','white', 'red'],
        ['style',<?php echo $num_white;?>,<?php echo $num_red;?>],
      ]);

      var options_fullStacked = {
          isStacked: 'percent',
axisTitlesPosition:'none',
chartArea:{left:0,top:0,width:'100%',height:'25%'},
	series:[{
	color:'#f1eaea'},{color:'#663333'}],
          legend: {position: 'none'},
          hAxis: {
            minValue: 0,
            ticks: [0, .25, .5, .75, 1]
          }
        };
    

      var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));
      chart.draw(data, options_fullStacked);
  }
  </script>



    <script type="text/javascript">
      google.charts.load('current', {'packages':['geochart'],mapsApiKey:'AIzaSyCnKjstnHrZ-_-cEg8wUCH-xeuA246KW2o'});
      google.charts.setOnLoadCallback(drawRegionsMap);
      
      function drawRegionsMap() {
        var data = google.visualization.arrayToDataTable([
          ['Country', 'Vineyards'],
          <?php  
                          while($row = mysqli_fetch_array($regions))  
                          {  
                               echo "['".$row["country"]."', ".$row["vineyards"]."],";  
                          }  
                          ?>  
        ]);

        var options = {
	fontName: 'Andale Mono',
          colorAxis: {colors: ['#f1eaea', '#663333'],
		enableRegionInteractivity:true

}
        };

        var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

        chart.draw(data, options);
      }
      </script>

<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([  
                          ['Grape', 'Number'],  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo "['".$row["grape_name"]."', ".$row["grape_count"]."],";  
                          }  
                          ?>  
                     ]);  


        var options = {
	colors:['#c1aeb4', 	
'#9c5b63',	
'#984548',
'#743535',
'#47363c',
'#f1eaea', 
'#663333'],        pieSliceText:'none'
	};

        var chart = new google.visualization.PieChart(document.getElementById("piechart"));

        chart.draw(data, options);
      }
  </script>

<script type='text/javascript'>
     google.charts.load('current', {
       'packages': ['geochart'],
       'mapsApiKey': 'AIzaSyCnKjstnHrZ-_-cEg8wUCH-xeuA246KW2o'
     });
     google.charts.setOnLoadCallback(drawMarkersMap);

      function drawMarkersMap() {
      var data = google.visualization.arrayToDataTable([
        ['County','Customers'],
			<?php  
                          while($row = mysqli_fetch_array($county))  
                          {  
                               echo "['".$row["county"]."', ".$row["customers"]."],";  
                          }  
                          ?>          
      ]);

      var options = {
        region: 'IE',
        resolution: 'provinces',
 colorAxis: {colors: ['#f1eaea', 
'#663333'],
                enableRegionInteractivity:true

}
        };
      var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    };
    </script>

<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Month', 'Order Total'],
          <?php  
                          while($row = mysqli_fetch_array($monthly_orders))  
                          {  
                               echo "['".$row["month"]."', ".$row["order_total"]."],";  
                          }  
                          ?> 
        ]);

        var options = {
          curveType: 'function',
          vAxis:{viewWindow: {min: 0}},
          legend: { position: 'bottom' },
	colors:['#663333']
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>



<div class = "banner">
			<div class = "logo"><a href=index.php>
			<img class = "img" src = "glassr.png" alt="glass" width="75" height="75">
			<h1>wine_
			<br>
			inline
			</h1></a>
			</div>

			<div class = "menu"
			<ul>
    				<li><a href=wine.php>wines</a><br><a href=winemaker.php>winemakers</a></li>
    				<li><a href=grape.php>grapes</a><br><a href=region.php>regions</a></li>
    				<li><a href=customer.php>customers</a><br><a href=address.php>addresses</a></li>
    				<li><a href=order.php>orders</a><br><a href=warehouse.php>warehouses</a></li>
			</ul>
			</div>
</div>


  </head>
  <body><div class="dash">
     <div class="style" align="center">style<div id="barchart_values" style="width: 100%; height: 100px;"></div>

    <div class="dashBody">
                                </div>
                        <div class="row">
                                        <div class="dashBox">grape frequency<div id="piechart" style="width: 900px; height: 500px;"></div></div>
                                        <div class="dashBox">customer locations<div id="chart_div" style="width: 650px; height: 350px;"></div></div>
                                </div>

                        <div class="row">
                                        <div class="dashBox">vineyard locations<div id="regions_div" style="width: 650px; height: 350px;"></div></div>
                                        <div class="dashBox">monthly order totals<div id="curve_chart" style="width: 650px; height: 350px;"></div></div>
                                </div>
                        </div>
		</div>

  </body>
</html>

