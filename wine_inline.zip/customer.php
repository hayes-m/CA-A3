<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);
	if(!$conn){
	die("Error: Failed to connect to database.");
	}

$customerOut=mysqli_query($conn,'select * from customer order by customer_id desc');

$recent=mysqli_query($conn,'select * from customer order by customer_id desc limit 1');

?>

<html>
        <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="style.css">

		<div class = "banner">
<div class = "logo"><a href=index.php>
                        <img class = "img" src = "glassr.png" alt="glass" width="75" height="75">
                        <h1>wine_
                        <br>
                        inline
                        </h1></a>
                        </div>
			<div class = "menu"
			<ul>
    				<li><a href=wine.php>wines</a><br><a href=winemaker.php>winemakers</a></li>
    				<li><a href=grape.php>grapes</a><br><a href=region.php>regions</a></li>
    				<li><a href=customer.php>customers</a><br><a href=address.php>addresses</a></li>
    				<li><a href=order.php>orders</a><br><a href=warehouse.php>warehouses</a></li>
			</ul>
			</div>
        	</div>
	</head>

        <body>
	<br>
	<div class = "split">
		
		<div class = "enter">
			<form action="customerUp.php" method="post">
				<h3>enter new customer</h3>

				<b>surname<br><input type="text" name="Surname" value=""/></b>
				<br><br>

				<b>forename<br><input type="text" name="Forename" value=""/></b>
				<br><br>

				<b>phone<br><input type="text" name="Phone" value=""/></b>
				<br><br>

				<b>email<br><input type="email" name="Email" value="" /></b>
				<br><br>

				<input type="submit" value="enter" />
            </form>
		<br>
		<hr>
		<div class="latest">

<?php
                echo "<br><b><i>latest entry: </i></b>";
                while($showrecent=mysqli_fetch_array($recent,MYSQLI_ASSOC)){
                echo "<br><b>customer id: </b>".$showrecent['customer_id'];
                echo "<br><b>surname: </b>".$showrecent['customer_surname'];
                echo "<br><b>forename: </b>".$showrecent['customer_forename'];
                echo "<br><b>phone: </b>".$showrecent['phone'];
                echo "<br><b>email: </b>".$showrecent['email'];
                }
?>
                </div>
                <br><hr><br>
                <b>DELETE RECORD</b>
                <form action="customerDown.php" method="post">
                customer_id#<br> <input type="number" name="cid" /><br>
                        <input type="submit" value="delete" />
                </form>

		</div>

		<div class="result">
			<br>
			<?php
				echo "<table border='0' cellspacing='0' width='100%'>
				<tr>
				<th>customer id</th>
				<th>surname</th>
				<th>forename</th>
				<th>phone</th>
				<th>email</th>
				</tr>";


				while($mycustomer=mysqli_fetch_array($customerOut,MYSQLI_ASSOC)){
			?>
				<div align="center"

			<?php
				echo "<tr>";
				echo "<td>".$mycustomer['customer_id']."</td>";
				echo "<td>".$mycustomer['customer_surname']."</td>";
				echo "<td>".$mycustomer['customer_forename']."</td>";
				echo "<td>".$mycustomer['phone']."</td>";
				echo "<td>".$mycustomer['email']."</td>";
				echo "</tr>";
				echo "</div>";
				}
				echo "</table>";

?>
	</body>
</html>


