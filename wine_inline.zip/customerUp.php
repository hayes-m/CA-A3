<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$customer_surname=$_POST['Surname'];
$customer_forename=$_POST['Forename'];
$phone=$_POST['Phone'];
$email=$_POST['Email'];

mysqli_query($conn,"INSERT into customer (customer_surname,customer_forename,phone,email) VALUES ('$customer_surname','$customer_forename','$phone','$email')");
header('Location: customer.php');
?>
