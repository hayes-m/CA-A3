<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$wine_name=$_POST['Wine_Name'];
$abv=$_POST['ABV'];
$grape_id=$_POST['Grape_Name'];
$price=$_POST['Price'];
$stock=$_POST['Stock'];
$winemaker_id=$_POST['Winemaker_Name'];

$updater="INSERT into wine (wine_name,abv,grape_id,price,stock,winemaker_id) VALUES ('$wine_name','$abv','$grape_id','$price','$stock','$winemaker_id')";

mysqli_query($conn,$updater);
header('Location: wine.php');

?>


