<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$winemaker_name=$_POST['Winemaker_Name'];
$vineyard=$_POST['Vineyard'];
$year_established=$_POST['Year_Established'];
$region_id=$_POST['Region_Name'];

mysqli_query($conn,"INSERT into winemaker (winemaker_name,vineyard,year_established,region_id) VALUES ('$winemaker_name','$vineyard','$year_established','$region_id')");
header('Location: winemaker.php');
?>
