<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$warehouse_ecode=$_POST['Warehouse_Ecode'];
$warehouse_saddress=$_POST['Warehouse_SAddress'];
$warehouse_county=$_POST['Warehouse_County'];
$warehouse_phone=$_POST['Warehouse_Phone'];
$warehouse_email=$_POST['Warehouse_Email'];
$warehouse_manager=$_POST['Warehouse_Manager'];

mysqli_query($conn,"INSERT into warehouse VALUES ('$warehouse_ecode','$warehouse_saddress','$warehouse_county','$warehouse_phone','$warehouse_email','$warehouse_manager')");
header('Location: warehouse.php');
?>


