<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);
	if(!$conn){
	die("Error: Failed to connect to database.");
	}

$warehouseOut=mysqli_query($conn,'select * from warehouse');
?>

<html>
        <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="style.css">

		<div class = "banner">
<div class = "logo"><a href=index.php>
                        <img class = "img" src = "glassr.png" alt="glass" width="75" height="75">
                        <h1>wine_
                        <br>
                        inline
                        </h1></a>
                        </div>
			<div class = "menu"
			<ul>
 				<li><a href=wine.php>wines</a><br><a href=winemaker.php>winemakers</a></li>
    				<li><a href=grape.php>grapes</a><br><a href=region.php>regions</a></li>
    				<li><a href=customer.php>customers</a><br><a href=address.php>addresses</a></li>
    				<li><a href=order.php>orders</a><br><a href=warehouse.php>warehouses</a></li>
			</ul>
			</div>
        	</div>
	</head>

        <body>
	<br>
	
		<div>
		<br>
<?php

		echo "<table border='0' cellspacing='0' width='100%'>
		<tr>
		<th>warehouse eircode</th>
		<th>street address</th>
		<th>county</th>
		<th>phone</th>
		<th>email</th>
		<th>manager</th>
		</tr>";


		while($mywarehouse=mysqli_fetch_array($warehouseOut,MYSQLI_ASSOC)){
?>
		<div align="center"

<?php
		echo "<tr>";
		echo "<td>".$mywarehouse['warehouse_ecode']."</td>";
        echo "<td>".$mywarehouse['warehouse_saddress']."</td>";
        echo "<td>".$mywarehouse['warehouse_county']."</td>";
        echo "<td>".$mywarehouse['warehouse_phone']."</td>";
        echo "<td>".$mywarehouse['warehouse_email']."</td>";
        echo "<td>".$mywarehouse['warehouse_manager']."</td>";	
		echo "</tr>";
		echo "</div>";
		}
		echo "</table>";

?>
	</body>
</html>


