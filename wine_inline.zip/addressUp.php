<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);

$customer_id=$_POST['CustomerID'];
$street=$_POST['Street'];
$eircode=$_POST['Eircode'];
$county=$_POST['County'];

mysqli_query($conn,"INSERT into address (customer_id,street,eircode,county) VALUES ('$customer_id','$street','$eircode','$county')");
header('Location: address.php');
?>


