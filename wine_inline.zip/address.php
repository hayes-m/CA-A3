<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);
	if(!$conn){
	die("Error: Failed to connect to database.");
	}

$addressOut=mysqli_query($conn,'select * from address order by customer_id desc');

$county=mysqli_query($conn,'select distinct county from address order by county asc');

$customer_id=mysqli_query($conn,'select c.customer_id from customer c natural left join address a where a.customer_id is null');

$recent=mysqli_query($conn,'select * from address order by customer_id desc limit 1');

?>

<html>
        <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="style.css">

		<div class = "banner">
			<div class = "logo"><a href=index.php>
                        <img class = "img" src = "glassr.png" alt="glass" width="75" height="75">
                        <h1>wine_
                        <br>
                        inline
                        </h1></a>
                        </div>


			<div class = "menu"
			<ul>
    				<li><a href=wine.php>wines</a><br><a href=winemaker.php>winemakers</a></li>
    				<li><a href=grape.php>grapes</a><br><a href=region.php>regions</a></li>
    				<li><a href=customer.php>customers</a><br><a href=address.php>addresses</a></li>
    				<li><a href=order.php>orders</a><br><a href=warehouse.php>warehouses</a></li>
			</ul>
			</div>
        	</div>
	</head>

        <body>
	<br>
	<div class = "split">
		
		<div class = "enter">
			<form action="addressUp.php" method="post">
				<h3>enter new address</h3>

				<b>customer id</b><br>
				<select name="CustomerID">
                                        <option>select</option>
                                        <?php
                                        while($idata=mysqli_fetch_array($customer_id)){
                                        echo "<option value='".$idata['customer_id']."'>" .$idata['customer_id'] ."</option>";
                                        }
                                        ?>
                                        </select>
<br><br>

				<b>street</b><br>
				<input type="text" name="Street" value="" /></b>
                <br><br>
				
				<b>county</b><br>
					<select name="County">
					<option>select</option>
					<?php
					while($cdata=mysqli_fetch_array($county)){
					echo "<option value='".$cdata['county']."'>" .$cdata['county'] ."</option>";
					}
					?>
					</select>
                    <br><br>
                
				<b>eircode</b><br>
				<input type="text" name="Eircode" value="" minlength="7" maxlength="7" /></b>
				<br><br>
		
				<input type="submit" value="enter" />
            </form>

 		<div class="latest">
                <br>
                <hr>

<?php
                echo "<br><b><i>latest entry: </i></b>";
                while($showrecent=mysqli_fetch_array($recent,MYSQLI_ASSOC)){
                echo "<br><b>customer id: </b>".$showrecent['customer_id'];
                echo "<br><b>street: </b>".$showrecent['street'];
                echo "<br><b>county: </b>".$showrecent['county'];
                echo "<br><b>eircode: </b>".$showrecent['eircode'];
                }
?>
                </div>

		</div>

		<div class="result">
			<br>
			<?php
				echo "<table border='0' cellspacing='0' width='100%'>
				<tr>
				<th>customer id</th>
				<th>street</th>
				<th>county</th>
				<th>eircode</th>
				</tr>";


				while($myaddress=mysqli_fetch_array($addressOut,MYSQLI_ASSOC)){
			?>
				<div align="center"

			<?php
				echo "<tr>";
				echo "<td>".$myaddress['customer_id']."</td>";
				echo "<td>".$myaddress['street']."</td>";
				echo "<td>".$myaddress['county']."</td>";
				echo "<td>".$myaddress['eircode']."</td>";
				echo "</tr>";
				echo "</div>";
				}
				echo "</table>";

?>
	</body>
</html>



