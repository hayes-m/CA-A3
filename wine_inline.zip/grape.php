<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);
	if(!$conn){
	die("Error: Failed to connect to database.");
	}

$grapeOut=mysqli_query($conn,'select * from grape order by grape_id desc');

$style=mysqli_query($conn,'select style from grape');

$recent=mysqli_query($conn,'select * from grape order by grape_id desc limit 1');

?>

<html>
        <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="style.css">

		<div class = "banner">
<div class = "logo"><a href=index.php>
                        <img class = "img" src = "glassr.png" alt="glass" width="75" height="75">
                        <h1>wine_
                        <br>
                        inline
                        </h1></a>
                        </div>
			<div class = "menu"
			<ul>
    				<li><a href=wine.php>wines</a><br><a href=winemaker.php>winemakers</a></li>
    				<li><a href=grape.php>grapes</a><br><a href=region.php>regions</a></li>
    				<li><a href=customer.php>customers</a><br><a href=address.php>addresses</a></li>
    				<li><a href=order.php>orders</a><br><a href=warehouse.php>warehouses</a></li>
			</ul>
			</div>
        	</div>
	</head>

        <body>
	<br>
	<div class = "split">
		<div class = "enter">

			<form action="grapeUp.php" method="post">
                        <h3>enter new grape</h3>

                        <b>grape name<br><input type="text" name="Grape_Name" value=""/></b>
                        <br><br>

			<b>style</b><br>
				<select name="Style">
				<option>select</option>
				<option value="Red">red</option>
				<option value="White">white</option>
				</select>
                        <br><br>

				<input type="submit" value="enter" />
			</form>
		<div class="latest">
                <br>
                <hr>

<?php
                echo "<br><b><i>latest entry: </i></b>";
                while($showrecent=mysqli_fetch_array($recent,MYSQLI_ASSOC)){
                echo "<br><b>grape id: </b>".$showrecent['grape_id'];
                echo "<br><b>grape name: </b>".$showrecent['grape_name'];
                echo "<br><b>style: </b>".$showrecent['style'];
                }
?>
                </div>

		</div>

		<div class="result">
		<br>
<?php

		echo "<table border='0' cellspacing='0' width='100%'>
		<tr>
		<th>grape id</th>
		<th>grape name</th>
		<th>style</th>
		</tr>";
		
		while($mygrape=mysqli_fetch_array($grapeOut,MYSQLI_ASSOC)){
?>
		<div align="center"

<?php
		echo "<tr>";
		echo "<td>".$mygrape['grape_id']."</td>";
		echo "<td>".$mygrape['grape_name']."</td>";
		echo "<td>".$mygrape['style']."</td>";
		echo "</tr>";
		echo "</div>";
		}
		echo "</table>";

?>
	</body>
</html>



