<?php
$user='root';
$pass='shire';
$host='127.0.0.1';
$db='wine_inline';
$conn=mysqli_connect($host,$user,$pass,$db);
	if(!$conn){
	die("Error: Failed to connect to database.");
	}

$regionOut=mysqli_query($conn,'select * from region');

$country=mysqli_query($conn,'select distinct country from region order by country asc');

?>

<html>
        <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="style.css">

		<div class = "banner">
<div class = "logo"><a href=index.php>
                        <img class = "img" src = "glassr.png" alt="glass" width="75" height="75">
                        <h1>wine_
                        <br>
                        inline
                        </h1></a>
                        </div>
			<div class = "menu"
			<ul>
    				<li><a href=wine.php>wines</a><br><a href=winemaker.php>winemakers</a></li>
    				<li><a href=grape.php>grapes</a><br><a href=region.php>regions</a></li>
    				<li><a href=customer.php>customers</a><br><a href=address.php>addresses</a></li>
    				<li><a href=order.php>orders</a><br><a href=warehouse.php>warehouses</a></li>
			</ul>
			</div>
        	</div>
	</head>

        <body>
	<br>
	<div class = "split">
		<div class = "enter">

			<form action="regionUp.php" method="post">
				<h3>enter new region</h3>

				<b>region name<br><input type="text" name="Region_Name" value=""/></b>
				<br><br>

				<b>country</b><br>
					<select name="Country">
					<option>select</option>
					<?php
					while($cdata=mysqli_fetch_array($country)){
					echo "<option value='".$cdata['country']."'>" .$cdata['country'] ."</option>";
					}
					?>
					</select>
					<br><br>

			<input type="submit" value="enter" />
                </form>
		</div>

		<div class="result">
		<br>
<?php
		echo "<table border='0' cellspacing='0' width='100%'>
		<tr>
		<th>region id</th>
		<th>region name</th>
		<th>country</th>
		</tr>";

		while($myregion=mysqli_fetch_array($regionOut,MYSQLI_ASSOC)){
?>
		<div align="center"

<?php
		echo "<tr>";
		echo "<td>".$myregion['region_id']."</td>";
		echo "<td>".$myregion['region_name']."</td>";
		echo "<td>".$myregion['country']."</td>";
		echo "</tr>";
		echo "</div>";
		}
		echo "</table>";

?>
	</body>
</html>


